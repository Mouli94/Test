import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,Validators} from "@angular/forms";
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
regform:FormGroup;
submitted:boolean=false;
  constructor(private fb : FormBuilder) { }

 /* ngOnInit() {
    this.regform=new FormGroup(
      {
        firstname : new FormControl(),
        lastname : new FormControl(),
        Gender : new FormControl(),
        DOB : new FormControl(),
        MOBILENO : new FormControl(),
        Email: new FormControl(),
        Password: new FormControl(),
        ConfirmPassword : new FormControl(),
  
      });

  } 
  
 
  }*/
  ngOnInit(){
    this.regform=this.fb.group({
      firstname:['',Validators.required],
      lastname : ['',Validators.required],
      Gender : ['',Validators.required],
      DOB : ['',Validators.required],
      MOBILENO : ['',Validators.required],
      Email: ['',[Validators.required,Validators.email]],
      Password: ['',[Validators.required,Validators.minLength(5),Validators.maxLength(10)]],
      ConfirmPassword : ['',Validators.required],

    })
  }
  get P(){
    return this.regform.controls
  }

  onSubmit(){
    this.submitted=true;
    if(this.regform.invalid){
      return;
    }
    else{
      alert("Data Submitted Successfully \n\n"+JSON.stringify(this.regform.value))
    }
    console.log(this.regform.value);  
  }
}