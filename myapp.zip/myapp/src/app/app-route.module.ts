import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router'
import { RegistrationComponent } from './registration/registration.component';

const route :Routes=[
 {path:"register",component:RegistrationComponent}
]
@NgModule({
  imports: [
    RouterModule.forRoot(route)
  ],
  exports:[RouterModule]

})
export class AppRouteModule { }
